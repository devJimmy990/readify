// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'downloads_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$downloadsNotifierHash() => r'0d6f5a219b827c583e34644ce9648aab135846c0';

/// See also [DownloadsNotifier].
@ProviderFor(DownloadsNotifier)
final downloadsNotifierProvider = AutoDisposeAsyncNotifierProvider<
    DownloadsNotifier, List<Map<String, dynamic>>>.internal(
  DownloadsNotifier.new,
  name: r'downloadsNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$downloadsNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DownloadsNotifier
    = AutoDisposeAsyncNotifier<List<Map<String, dynamic>>>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
