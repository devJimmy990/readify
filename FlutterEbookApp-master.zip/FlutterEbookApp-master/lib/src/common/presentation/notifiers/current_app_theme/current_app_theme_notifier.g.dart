// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'current_app_theme_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$currentAppThemeNotifierHash() =>
    r'ea70b7c6ad6193732228f3ea9a29d7f3139ba1d7';

/// See also [CurrentAppThemeNotifier].
@ProviderFor(CurrentAppThemeNotifier)
final currentAppThemeNotifierProvider = AutoDisposeAsyncNotifierProvider<
    CurrentAppThemeNotifier, CurrentAppTheme>.internal(
  CurrentAppThemeNotifier.new,
  name: r'currentAppThemeNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$currentAppThemeNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CurrentAppThemeNotifier = AutoDisposeAsyncNotifier<CurrentAppTheme>;
// ignore_for_file: unnecessary_raw_strings, subtype_of_sealed_class, invalid_use_of_internal_member, do_not_use_environment, prefer_const_constructors, public_member_api_docs, avoid_private_typedef_functions
