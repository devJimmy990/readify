String get isDarkModeKey => 'isDarkMode';
