import 'package:dio/dio.dart';

HttpClientAdapter getAdapter() {
  throw 'unsupported platform';
}
