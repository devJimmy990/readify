export 'unsupported.dart'
    if (dart.library.html) 'web_adapter.dart'
    if (dart.library.io) 'mobile_adapter.dart';
