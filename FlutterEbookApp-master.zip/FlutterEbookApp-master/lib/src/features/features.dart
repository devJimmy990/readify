export 'book_details/book_details.dart';
export 'downloads/downloads.dart';
export 'explore/explore.dart';
export 'favorites/favourites.dart';
export 'home/home.dart';
export 'settings/settings.dart';
export 'splash/splash.dart';
export 'tabs/tabs.dart';
