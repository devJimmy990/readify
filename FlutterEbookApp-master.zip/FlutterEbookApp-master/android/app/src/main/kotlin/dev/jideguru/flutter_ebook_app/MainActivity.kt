package dev.jideguru.flutter_ebook_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}