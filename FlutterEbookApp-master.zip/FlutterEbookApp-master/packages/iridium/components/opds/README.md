# mno_opds

This is an unofficial port of [Readium 2](https://readium.org/technical/r2-toc/) OPDS parsers: [Kotlin](https://github.com/readium/r2-opds-kotlin), [Swift](https://github.com/readium/r2-opds-swift) and [JavaScript](https://github.com/readium/r2-opds-js).
