## 0.1.1

* Migration to null-safety

## 0.1.0

* Provide OPDS parsers for OPDS1 and OPDS2
