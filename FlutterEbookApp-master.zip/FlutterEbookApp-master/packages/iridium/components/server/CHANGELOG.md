## 0.1.0

* Contains the server functions to serve resources in the webview.
* Support null-safety
