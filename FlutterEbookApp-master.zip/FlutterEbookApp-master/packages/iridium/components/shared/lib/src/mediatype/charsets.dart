// Copyright (c) 2021 Mantano. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

class Charsets {
  static const String utf8 = "UTF-8";
  static const String utf16 = "UTF-16";
}
