# mno_shared

Contains the definitions of the custom types (model) used across the Mantano Dart/Flutter ports of Readium modules.
