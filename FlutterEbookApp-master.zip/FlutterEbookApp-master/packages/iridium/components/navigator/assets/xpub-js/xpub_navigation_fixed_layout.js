(function() {
    xpub.navigation.openPage = function(pageRequest) {
        console.log("pageRequest", pageRequest);
    };

    xpub.navigation.redraw = function() {
    };

    xpub.navigation.computePagesForElementId = function(contentRefUrls, sourceFileHref) {
    };

    xpub.navigation.insureElementVisibility = function(spineItemId, element, initiator) {
    };

    xpub.updatePagination = function() {
    };

    xpub.navigateToStart = function() {
    };

    xpub.navigateToEnd = function() {
    };
})();