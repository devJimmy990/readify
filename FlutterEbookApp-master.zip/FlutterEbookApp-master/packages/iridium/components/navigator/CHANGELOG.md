## 0.1.0

* Provide navigator support for epub and cbz files
